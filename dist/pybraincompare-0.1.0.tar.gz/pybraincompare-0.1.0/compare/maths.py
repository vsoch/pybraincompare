

def percent_to_float(x):
  return float(x.strip('%'))/100

'''Calculate pearson correlation for two images'''
def do_pearson(image1,image2):
  print "vanessa write me!"
